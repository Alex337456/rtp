// Функція для кнопки "Замовити зараз"
document.getElementById("order-now").addEventListener("click", function() {
    alert("Дякуємо! Наш менеджер зв’яжеться з вами.");
});

// Функція для форми контактів
document.getElementById("contact-form").addEventListener("submit", function(e) {
    e.preventDefault(); // Зупиняємо відправку форми
    alert("Ваше повідомлення надіслано!");
    document.getElementById("contact-form").reset(); // Очищаємо форму
});

// Функція для гамбургер-меню
function toggleMenu() {
    const nav = document.querySelector('header nav');
    nav.classList.toggle('open');
}
